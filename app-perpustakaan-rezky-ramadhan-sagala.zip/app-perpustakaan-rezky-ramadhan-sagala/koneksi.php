<?php
if (!function_exists('format_tanggal')) {
    date_default_timezone_set("Asia/Jakarta");

    function format_tanggal($datetime)
    {
        $bulan = array(
            1 => 'Januari',
            2 => 'Februari',
            3 => 'Maret',
            4 => 'April',
            5 => 'Mei',
            6 => 'Juni',
            7 => 'Juli',
            8 => 'Agustus',
            9 => 'September',
            10 => 'Oktober',
            11 => 'November',
            12 => 'Desember'
        );

        if (empty($datetime) || $datetime == '0000-00-00 00:00:00') {
            return 'Belum diset';
        }

        $date = new DateTime($datetime);
        $day = $date->format('d');
        $month = $bulan[(int)$date->format('m')];
        $year = $date->format('Y');
        $time = $date->format('H:i');

        return "$day $month $year, $time WIB";
    }
}

$server = "localhost";
$root = "root";
$pass = "";
$db = "ukk_nama";
$koneksi = mysqli_connect($server, $root, $pass, $db);
if (!$koneksi) {
    die("Koneksi Gagal: " . mysqli_connect_error());
}
