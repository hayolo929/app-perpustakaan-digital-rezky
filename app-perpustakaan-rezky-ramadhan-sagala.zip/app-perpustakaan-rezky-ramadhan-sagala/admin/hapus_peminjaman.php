<?php
include '../koneksi.php';

$id_transaksi = $_GET['id'];
$delete = mysqli_query($koneksi, "DELETE FROM transaksi WHERE id_transaksi='$id_transaksi'");
if ($delete) {
    echo "<script>alert('✅ Data Peminjaman berhasil dihapus'); window.location.assign('?halaman=data_peminjaman');</script>";
} else {
    echo "<script>alert('❌ Gagal hapus'); window.location.assign('?halaman=data_peminjaman');</script>";
}
