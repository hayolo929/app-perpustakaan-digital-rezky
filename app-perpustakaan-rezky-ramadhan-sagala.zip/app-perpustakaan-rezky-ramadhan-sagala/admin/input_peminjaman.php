<h4>🛒 Tambah Data Peminjaman</h4>
<?php
include '../koneksi.php';
$anggota = mysqli_query($koneksi, "SELECT * FROM anggota ORDER BY nama_anggota");
$buku = mysqli_query($koneksi, "SELECT * FROM buku WHERE stock > 0 ORDER BY judul_buku");
?>
<form method="post" action="#" class="mt-3">
    <select name="id_anggota" class="form-control mb-2" required>
        <option value=""> === Pilih Anggota ===</option>
        <?php while ($a = mysqli_fetch_array($anggota)) {
            echo "<option value='$a[id_anggota]'>$a[nama_anggota] ($a[nis])</option>";
        } ?>
    </select>
    <select name="id_buku" class="form-control mb-2" required>
        <option value=""> === Pilih Buku ===</option>
        <?php while ($b = mysqli_fetch_array($buku)) {
            echo "<option value='$b[id_buku]'>$b[judul_buku]</option>";
        } ?>
    </select>
    <input type="datetime-local" name="tgl_pinjam" class="form-control mb-2" value="<?php echo date('Y-m-d\TH:i'); ?>" required>
    <label class="form-label">Durasi Peminjaman (hari):</label>
    <select name="durasi_hari" class="form-control mb-2" required>
        <option value="1">1 hari</option>
        <option value="3">3 hari</option>
        <option value="7" selected>7 hari</option>
        <option value="14">14 hari</option>
    </select>
    <button type="submit" name="tombol" class="btn btn-primary"> 💾 Simpan Peminjaman </button>
</form>

<?php
if (isset($_POST['tombol'])) {
    $id_anggota = $_POST['id_anggota'];
    $id_buku = $_POST['id_buku'];
    $tgl_pinjam_input = $_POST['tgl_pinjam'];
    $durasi_hari = (int)$_POST['durasi_hari'];

    $tgl_pinjam = date('Y-m-d H:i:s', strtotime($tgl_pinjam_input));
    $tgl_kembali = date('Y-m-d H:i:s', strtotime($tgl_pinjam_input . " +$durasi_hari days"));
    $status_transaksi = "Peminjaman";

    $query = "INSERT INTO transaksi (id_anggota,id_buku,tgl_pinjam,tgl_kembali,status_transaksi) VALUES ('$id_anggota','$id_buku','$tgl_pinjam','$tgl_kembali','$status_transaksi')";
    $data = mysqli_query($koneksi, $query);
    if ($data) {
        mysqli_query($koneksi, "UPDATE buku SET status='tidak' WHERE id_buku='$id_buku'");
        echo "<script>alert('✅ Data Transaksi Peminjaman Berhasil Disimpan nPinjam: " . format_tanggal($tgl_pinjam) . "nKembali: " . format_tanggal($tgl_kembali) . "'); window.location.assign('?halaman=data_peminjaman');</script>";
    } else {
        echo "<script>alert('❌ Maaf Data Transaksi Peminjaman Gagal Disimpan'); window.location.assign('?halaman=input_peminjaman');</script>";
    }
}
?>