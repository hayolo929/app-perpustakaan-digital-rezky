<h4> 👥 Data Anggota</h4>
<?php
$kunci = isset($_POST['kunci']) ? $_POST['kunci'] : "";
?>
<form action="" method="post">
    <label class="text-muted">Cari Anggota</label>
    <div class="input-group mb-3">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
        <input type="text" name="kunci" class="form-control" placeholder="Masukkan Nama Anggota" value="<?php echo $kunci; ?>">
        <button class="btn btn-primary" type="submit">🔍 Cari</button>
    </div>

</form>
<?php if ($kunci): ?>
    <h6 class="text-primary">🔍 Hasil pencarian "<?php echo $kunci; ?>"</h6>
<?php endif; ?>
<a href="?halaman=input_anggota" class="btn btn-secondary">
    ➕ Tambah Data Anggota
</a>
<table class="table table-bordered mt-3">
    <tr class="table-primary fw-bold text-center">
        <td class="align-middle">No</td>
        <td class="align-middle">NIS</td>
        <td class="align-middle">Nama Anggota</td>
        <td class="align-middle">Username</td>
        <td class="align-middle">Password</td>
        <td class="align-middle">Kelas</td>
        <td class="align-middle">Aksi</td>
    </tr>
    <?php
    include '../koneksi.php';
    $no = 0;
    $query = "SELECT * FROM anggota";
    if ($kunci) $query .= " WHERE nama_anggota LIKE '%$kunci%'";
    $query .= " ORDER BY id_anggota DESC";
    $data = mysqli_query($koneksi, $query);
    foreach ($data as $anggota) { ?>
        <tr class="text-center">
            <td class="align-middle"><?php echo ++$no; ?></td>
            <td class="align-middle"><?php echo $anggota['nis']; ?></td>
            <td class="align-middle"><?php echo $anggota['nama_anggota']; ?></td>
            <td class="align-middle"><?php echo $anggota['username']; ?></td>
            <td class="align-middle"><?php echo $anggota['password']; ?></td>
            <td class="align-middle"><?php echo $anggota['kelas']; ?></td>
            <td class="align-middle">
                <a href="?halaman=edit_anggota&id=<?php echo $anggota['id_anggota']; ?>" class="btn btn-warning text-white">🖊️ Edit</a>
                <a href="?halaman=hapus_anggota&id=<?php echo $anggota['id_anggota']; ?>" class="btn btn-danger text-white" onclick="return confirm('Yakin Ingin Menghapus Data Anggota Ini..?')"> 🚮 Hapus</a>
            </td>
        </tr>

    <?php } ?>

</table>