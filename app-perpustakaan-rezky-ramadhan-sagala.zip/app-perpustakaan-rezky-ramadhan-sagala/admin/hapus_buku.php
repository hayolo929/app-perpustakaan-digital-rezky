<?php

include '../koneksi.php';
$id = $_GET['id'];
$query = "DELETE FROM buku WHERE id_buku='$id'";
$data = mysqli_query($koneksi, $query);
if ($data) {
    echo "<script>alert('✅ Data Buku Berhasil Dihapus'); window.location.assign('?halaman=data_buku');</script>";
} else {
    echo "<script>alert('❌ Maaf Data Buku Gagal Dihapus'); window.location.assign('?halaman=data_buku');</script>";
}
