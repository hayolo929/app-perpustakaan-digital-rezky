<h4> 🛒 Data Transaksi Peminjaman</h4>
<a href="?halaman=input_peminjaman" class="btn btn-secondary mb-3">➕ Tambah Peminjaman</a>
<?php
$kunci1 = isset($_POST['kunci1']) ? $_POST['kunci1'] : "";
?>
<form action="" method="post">
    <label class="text-muted">Cari Peminjaman</label>
    <div class="input-group mb-3">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
        <input type="text" name="kunci1" class="form-control" placeholder="Masukkan Nama Anggota" value="<?php echo $kunci1; ?>">
        <button class="btn btn-primary" type="submit">🔍 Cari</button>
    </div>

</form>
<?php if ($kunci1): ?>
    <h6 class="text-primary">🔍 Hasil pencarian "<?php echo $kunci1; ?>"</h6>
<?php endif; ?>
<table class="table  table-bordered mt-3">
    <tr class="table-primary fw-bold text-center">
        <td class="align-middle">No</td>
        <td class="align-middle">NIS</td>
        <td class="align-middle">Nama Anggota</td>
        <td class="align-middle">Judul Buku</td>
        <td class="align-middle">Tanggal Peminjaman</td>
        <td class="align-middle">Tanggal Kembali</td>
        <td class="align-middle">Aksi</td>
    </tr>
    <?php
    include '../koneksi.php';
    $no = 0;
    $query = "SELECT * FROM transaksi,buku,anggota WHERE buku.id_buku=transaksi.id_buku AND anggota.id_anggota=transaksi.id_anggota AND transaksi.status_transaksi='Peminjaman'";
    if ($kunci1) $query .= " AND nama_anggota LIKE '%$kunci1%'";
    $query .= " ORDER BY transaksi.id_transaksi DESC";
    $data = mysqli_query($koneksi, $query);
    foreach ($data as $peminjam) { ?>
        <tr class="text-center">
            <td class="align-middle"><?php echo ++$no; ?></td>
            <td class="align-middle"><?php echo $peminjam['nis']; ?></td>
            <td class="align-middle"><?php echo $peminjam['nama_anggota']; ?></td>
            <td class="align-middle text-nowrap"><?php echo $peminjam['judul_buku']; ?></td>
            <td class="align-middle "><?php echo format_tanggal($peminjam['tgl_pinjam']); ?></td>
            <td class="align-middle"><?php echo format_tanggal($peminjam['tgl_kembali']); ?></td>
            <td class="align-middle text-nowrap">
                <a href="?halaman=edit_peminjaman&id=<?php echo $peminjam['id_transaksi']; ?>" class="btn btn-warning btn-sm ">🖊️ Edit</a>
                <a href="?halaman=extend_peminjaman&id=<?php echo $peminjam['id_transaksi']; ?>&tgl_kembali=<?php echo $peminjam['tgl_kembali']; ?>"
                    class="btn btn-info btn-sm text-white" onclick="return confirm('Perpanjang 7 hari?')">⏰ Extend</a>
                <?php
                $pesan = " 🚮 Anda Yakin Ingin Menghapus buku oleh " . $peminjam['nama_anggota'] . ", Buku " . $peminjam['judul_buku'];
                ?>
                <a onclick="hapus('<?php echo $pesan; ?>', <?php echo $peminjam['id_transaksi']; ?>)" class="btn btn-danger btn-sm">🚮 Hapus</a>
            </td>
        </tr>
    <?php } ?>
</table>

<h4>✅ Data Transaksi pengembalian </h4>
<?php
$kunci2 = isset($_POST['kunci2']) ? $_POST['kunci2'] : "";
?>
<form action="" method="post">
    <label class="text-muted">Cari Pengembalian</label>
    <div class="input-group mb-3">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
        <input type="text" name="kunci2" class="form-control" placeholder="Masukkan Nama Anggota" value="<?php echo $kunci2; ?>">
        <button class="btn btn-primary" type="submit">🔍 Cari</button>
    </div>

</form>
<?php if ($kunci2): ?>
    <h6 class="text-primary">🔍 Hasil pencarian "<?php echo $kunci2; ?>"</h6>
<?php endif; ?>
<table class="table table-bordered mt-3">
    <tr class="table-primary fw-bold text-center">
        <td class="align-middle">No</td>
        <td class="align-middle">NIS</td>
        <td class="align-middle">Nama Anggota</td>
        <td class="align-middle">Judul Buku</td>
        <td class="align-middle">Tanggal Peminjaman</td>
        <td class="align-middle">Tanggal Pengembalian</td>
        <td class="align-middle">Aksi</td>
    </tr>
    <?php
    include '../koneksi.php';
    $no = 0;
    $query = "SELECT * FROM transaksi,buku,anggota WHERE buku.id_buku=transaksi.id_buku
     AND anggota.id_anggota=transaksi.id_anggota AND transaksi.status_transaksi='Pengembalian'";
    if ($kunci2) $query .= " AND nama_anggota LIKE '%$kunci2%'";
    $query .= " ORDER BY transaksi.id_transaksi DESC";
    $data = mysqli_query($koneksi, $query);
    foreach ($data as $peminjam) { ?>
        <tr class="text-center">
            <td class="align-middle"><?php echo ++$no; ?></td>
            <td class="align-middle"><?php echo $peminjam['nis']; ?></td>
            <td class="align-middle"><?php echo $peminjam['nama_anggota']; ?></td>
            <td class="align-middle"><?php echo $peminjam['judul_buku']; ?></td>
            <td class="align-middle"><?php echo format_tanggal($peminjam['tgl_pinjam']); ?></td>
            <td class="align-middle"><?php echo format_tanggal($peminjam['tgl_kembali']); ?></td>
            <td class="align-middle">
                <?php
                $pesan = "🚮 Hapus transaksi pengembalian " . $peminjam['judul_buku'] . " oleh " . $peminjam['nama_anggota'] . "?";
                ?>
                <a onclick="hapusPengembalian('<?php echo $pesan; ?>', <?php echo $peminjam['id_transaksi']; ?>)" class="btn btn-danger btn-sm">🗑️ Hapus</a>
            </td>
        </tr>
    <?php } ?>
</table>
<script>
    function pengembalian(pesan, id_transaksi, id_buku) {
        if (confirm(pesan)) {
            window.location.href = '?halaman=proses_pengembalian&id=' + id_transaksi + '&buku=' + id_buku;
        }
    }

    function hapus(pesan, id_transaksi) {
        if (confirm(pesan)) {
            window.location.href = '?halaman=hapus_peminjaman&id=' + id_transaksi;
        }
    }

    function hapusPengembalian(pesan, id_transaksi) {
        if (confirm(pesan)) {
            window.location.href = '?halaman=hapus_peminjaman&id=' + id_transaksi;
        }
    }
</script>