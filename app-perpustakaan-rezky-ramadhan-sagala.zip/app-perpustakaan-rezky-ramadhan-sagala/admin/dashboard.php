<?php
session_start();
if (!isset($_SESSION['id_admin'])) {
    header("location:../login_admin.php");
}

include '../koneksi.php';

$total_buku = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM buku"))['total'];
$total_anggota = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM anggota"))['total'];
$total_pinjam = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM transaksi WHERE status_transaksi='Peminjaman'"))['total'];
$total_pengembalian = mysqli_fetch_array(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM transaksi WHERE status_transaksi='Pengembalian'"))['total'];
?>

<?php
$custom_styles = '<style>
        .card-gradient-buku {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            color: white !important;
        }
        .card-gradient-anggota {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%) !important;
            color: white !important;
        }
        .card-gradient-pinjam {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%) !important;
            color: white !important;
        }
        .card-gradient-pengembalian {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%) !important;
            color: white !important;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
        }
        .p-5 { padding: 2rem !important; }
    </style>';
include 'simple_header.php'; ?>

<!-- Stat Cards Row -->
<div class=" p-5 mt-3">
    <div class="row mt-4">
        <div class="col-md-3 mb-3">
            <div class="card card-gradient-buku h-70 shadow-lg text-center p-3">
                <i class="fas fa-book fa-2x mb-3"></i>
                <h5>Total Buku</h5>
                <div class="stat-number"><?php echo $total_buku; ?></div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card card-gradient-anggota h-70 shadow-lg text-center p-3">
                <i class="fas fa-users fa-2x mb-3"></i>
                <h5>Total Anggota</h5>
                <div class="stat-number"><?php echo $total_anggota; ?></div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card card-gradient-pinjam h-70 shadow-lg text-center p-3">
                <i class="fas fa-book-reader fa-2x mb-3"></i>
                <h5>Buku Dipinjam</h5>
                <div class="stat-number"><?php echo $total_pinjam; ?></div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card card-gradient-pengembalian h-70 shadow-lg text-center p-3">
                <i class="fas fa-undo fa-2x mb-3"></i>
                <h5>Pengembalian</h5>
                <div class="stat-number"><?php echo $total_pengembalian; ?></div>
            </div>
        </div>
    </div>



    <?php
    $halaman = isset($_GET['halaman']) ? $_GET['halaman'] : "";
    if (file_exists($halaman . ".php")) {
        include $halaman . ".php";
    } else { ?>
        <h4 class="mt-3">Selamat Datang di Dashboard <?= $_SESSION['nama_admin']; ?> 👏</h4>
        <p class="text-justify text-muted">
            Aplikasi Perpustakaan Sekolah Digital Merupakan sistem berbasis web
            yang dirancang untuk membantu pengelolahan data buku,peminjaman,
            dan pengembalian secara lebih mudah,cepat,dan terorganisir
        </p>
    <?php } ?>
</div>