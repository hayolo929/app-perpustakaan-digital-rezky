<?php
include '../koneksi.php';
$id = $_GET['id'];
$query = "DELETE FROM anggota WHERE id_anggota='$id'";
$data = mysqli_query($koneksi, $query);

if ($data) {
    echo "<script>alert('✅ Data Anggota Berhasil Dihapus'); window.location.assign('?halaman=data_anggota');</script>";
} else {
    echo "<script>alert('❌ Maaf Data Anggota Gagal Dihapus'); window.location.assign('?halaman=data_anggota');</script>";
}
