<h4>📚 Tambah Data Buku</h4>
<form method="post" action="#" class="mt-3">
    <input type="text" name="judul_buku" class="form-control mb-2" placeholder="Masukkan Judul Buku" required>
    <input type="text" name="pengarang" class="form-control mb-2" placeholder="Masukkan Nama Pengarang" required>
    <input type="text" name="penerbit" class="form-control mb-2" placeholder="Masukkan Nama Penerbit" required>
    <input maxlength="4" type="number" name="tahun_terbit" class="form-control mb-2" placeholder="Masukkan Tahun Terbit" required>
    <input type="number" name="stock" class="form-control mb-2" placeholder="Masukkan Stock Buku" value="1" min="0" required>
    <button type="submit" name="tombol" class="btn btn-primary"> 💾 Simpan Data Buku </button>
</form>

<?php
if (isset($_POST['tombol'])) {
    $judul_buku = $_POST['judul_buku'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $stock = $_POST['stock'];
    include '../koneksi.php';
    $query = "INSERT INTO buku (judul_buku,pengarang,penerbit,tahun_terbit,stock,status) VALUES ('$judul_buku','$pengarang','$penerbit','$tahun_terbit',$stock,'Tersedia')";
    $data = mysqli_query($koneksi, $query);
    if ($data) {
        echo "<script>alert('✅ Data Buku Berhasil Disimpan'); window.location.assign('?halaman=data_buku');</script>";
    } else {
        echo "<script>alert('❌ Maaf Data Buku Gagal Disimpan'); window.location.assign('?halaman=input_buku');</script>";
    }
}
?>