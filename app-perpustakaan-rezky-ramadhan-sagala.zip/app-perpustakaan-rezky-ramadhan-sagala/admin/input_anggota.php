<h4>👥 Tambah Data Anggota</h4>
<form method="post" action="#" class="mt-3">
    <input type="number" name="nis" class="form-control mb-2" placeholder="Masukkan NIS" required>
    <input type="text" name="nama_anggota" class="form-control mb-2" placeholder="Masukkan Nama Anggota" required>
    <input type="text" name="username" class="form-control mb-2" placeholder="Masukkan Username" required>
    <input type="password" name="password" class="form-control mb-2" placeholder="Masukkan Password" required>
    <input type="text" name="kelas" class="form-control mb-2" placeholder="Masukkan Kelas" required>
    <button type="submit" name="tombol" class="btn btn-primary"> 💾 Simpan Data Anggota</button>
</form>

<?php
if (isset($_POST['tombol'])) {
    $nis = $_POST['nis'];
    $nama_anggota = $_POST['nama_anggota'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $kelas = $_POST['kelas'];
    include '../koneksi.php';
    $query = "INSERT INTO anggota (nis,nama_anggota,username,password,kelas) VALUES ('$nis','$nama_anggota','$username','$password','$kelas')";
    $data = mysqli_query($koneksi, $query);
    if ($data) {
        echo "<script>alert('✅ Data Anggota Berhasil Disimpan'); window.location.assign('?halaman=data_anggota');</script>";
    } else {
        echo "<script>alert('❌ Maaf Data Anggota Gagal Disimpan'); window.location.assign('?halaman=input_anggota');</script>";
    }
}
?>