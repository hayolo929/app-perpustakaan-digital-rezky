<?php
include '../koneksi.php';

$id_transaksi = $_GET['id'];
$data_transaksi = mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM transaksi WHERE id_transaksi='$id_transaksi'"));
?>
<h4>🖊️ Edit Data Peminjaman #<?php echo $id_transaksi; ?></h4>
<form method="post" action="#" class="mt-3">
    <input type="hidden" name="id_transaksi" value="<?php echo $id_transaksi; ?>">
    <select name="id_anggota" class="form-control mb-2" required>
        <option value=""> === Pilih Anggota ===</option>
        <?php
        $anggota = mysqli_query($koneksi, "SELECT * FROM anggota");
        while ($a = mysqli_fetch_array($anggota)) {
            $selected = $a['id_anggota'] == $data_transaksi['id_anggota'] ? 'selected' : '';
            echo "<option value='$a[id_anggota]' $selected>$a[nama_anggota] ($a[nis])</option>";
        }
        ?>
    </select>
    <select name="id_buku" class="form-control mb-2" required>
        <option value=""> === Pilih Buku ===</option>
        <?php
        $buku = mysqli_query($koneksi, "SELECT * FROM buku");
        while ($b = mysqli_fetch_array($buku)) {
            $selected = $b['id_buku'] == $data_transaksi['id_buku'] ? 'selected' : '';
            echo "<option value='$b[id_buku]' $selected>$b[judul_buku]</option>";
        }
        ?>
    </select>
    <input type="datetime-local" name="tgl_pinjam" class="form-control mb-2" value="<?php echo date('Y-m-d\TH:i', strtotime($data_transaksi['tgl_pinjam'])); ?>" required>
    <input type="datetime-local" name="tgl_kembali" class="form-control mb-2" value="<?php echo date('Y-m-d\TH:i', strtotime($data_transaksi['tgl_kembali'])); ?>" required>
    <button type="submit" name="tombol" class="btn btn-primary"> 💾 Update Peminjaman </button>
    <a href="?halaman=data_peminjaman" class="btn btn-secondary">❌ Batal</a>
</form>

<?php
if (isset($_POST['tombol'])) {
    $id_transaksi = $_POST['id_transaksi'];
    $id_anggota = $_POST['id_anggota'];
    $id_buku = $_POST['id_buku'];
    $tgl_pinjam = $_POST['tgl_pinjam'];
    $tgl_kembali = $_POST['tgl_kembali'];

    $update = mysqli_query($koneksi, "UPDATE transaksi SET id_anggota='$id_anggota', id_buku='$id_buku', tgl_pinjam='$tgl_pinjam', tgl_kembali='$tgl_kembali' WHERE id_transaksi='$id_transaksi'");
    if ($update) {
        echo "<script>alert('✅ Data Peminjaman berhasil diupdate'); window.location.assign('?halaman=data_peminjaman');</script>";
    } else {
        echo "<script>alert('❌ Gagal update'); window.location.assign('?halaman=data_peminjaman');</script>";
    }
}
?>