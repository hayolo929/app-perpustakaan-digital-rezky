<?php
include '../koneksi.php';

$id_transaksi = $_GET['id'];
$tgl_kembali_lama = $_GET['tgl_kembali'];
$new_date = date('Y-m-d H:i:s', strtotime($tgl_kembali_lama . ' +7 days'));
$update = mysqli_query($koneksi, "UPDATE transaksi SET tgl_kembali='$new_date' WHERE id_transaksi='$id_transaksi'");
if ($update) {
    echo "<script>alert('✅ Tanggal pengembalian diperpanjang 7 hari'); window.location.assign('?halaman=data_peminjaman');</script>";
} else {
    echo "<script>alert('❌ Gagal memperpanjang'); window.location.assign('?halaman=data_peminjaman');</script>";
}
