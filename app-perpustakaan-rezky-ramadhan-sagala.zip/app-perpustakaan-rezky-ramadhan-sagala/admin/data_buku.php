<h4> 📚 Data Buku</h4>
<?php
$kunci = isset($_POST['kunci']) ? $_POST['kunci'] : "";
?>
<form action="" method="post">
    <label class="text-muted">Cari Buku</label>
    <div class="input-group mb-3">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
        <input type="text" name="kunci" class="form-control" placeholder="Masukkan Judul Buku" value="<?php echo $kunci; ?>">
        <button class="btn btn-primary" type="submit">🔍 Cari</button>
    </div>

</form>
<?php if ($kunci): ?>
    <h6 class="text-primary">🔍 Hasil pencarian "<?php echo $kunci; ?>"</h6>
<?php endif; ?>
<a href="?halaman=input_buku" class="btn btn-secondary">
    ➕ Tambah Data Buku
</a>
<table class="table table-bordered mt-3">
    <tr class="table-primary fw-bold text-center">
        <td class="align-middle">No</td>
        <td class="align-middle">Judul Buku</td>
        <td class="align-middle">Pengarang</td>
        <td class="align-middle">Penerbit</td>
        <td class="align-middle">Tahun Terbit</td>
        <td class="align-middle">Stock</td>
        <td class="align-middle">Status</td>
        <td class="align-middle">Aksi</td>
    </tr>
    <?php
    include '../koneksi.php';
    $no = 0;
    $query = "SELECT * FROM buku";
    if ($kunci) $query .= " WHERE judul_buku LIKE '%$kunci%'";
    $query .= " ORDER BY id_buku DESC";
    $data = mysqli_query($koneksi, $query);
    foreach ($data as $buku) { ?>
        <tr class="text-center">
            <td class="align-middle"><?php echo ++$no; ?></td>
            <td class="align-middle"><?php echo $buku['judul_buku']; ?></td>
            <td class="align-middle"><?php echo $buku['pengarang']; ?></td>
            <td class="align-middle"><?php echo $buku['penerbit']; ?></td>
            <td class="align-middle"><?php echo $buku['tahun_terbit']; ?></td>
            <td class="align-middle"><?php echo $buku['stock']; ?></td>
            <td class="align-middle"><?php if ($buku['stock'] > 0) echo "Tersedia";
                                        else echo "Habis"; ?></td>
            <td class="align-middle">
                <a href="?halaman=edit_buku&id=<?php echo $buku['id_buku']; ?>" class="btn btn-warning text-white">🖊️ Edit</a>
                <a href="?halaman=hapus_buku&id=<?php echo $buku['id_buku']; ?>" class="btn btn-danger text-white" onclick="return confirm('Yakin Ingin Menghapus Data Buku Ini..?')"> 🚮 Hapus</a>
            </td>
        </tr>

    <?php } ?>

</table>