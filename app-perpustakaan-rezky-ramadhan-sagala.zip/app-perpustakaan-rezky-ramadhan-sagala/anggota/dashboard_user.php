<?php
session_start();
if (!isset($_SESSION['id_anggota'])) {
    header("location:../login_anggota.php");
}

?>

<?php include 'simple_header.php'; ?>
<style>
    .content-wrapper section {
        padding: 2rem;
    }
</style>

<section class="min-height: 200px;">
    <div class="container col-md-12">


        <div class=" p-3 mt-3  ">
            <?php
            $halaman = isset($_GET['halaman']) ? $_GET['halaman'] : "";
            if (file_exists($halaman . ".php")) {
                include $halaman . ".php";
            } else { ?>
                <h4>Selamat Datang di Dashboard User <?php echo $_SESSION['nama_anggota']; ?> 👏</h4>
                <form action="?halaman=cari" method="post">
                    <label class="text-muted"> Yuk Cari Buku</label>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="kunci" class="form-control" required placeholder="Masukkan Judul Buku">
                        <button class="btn btn-primary" type="submit">🔍 Cari</button>
                    </div>

                </form>
                <h4>🛒 Daftar Buku yang di pinjam</h4>
                <?php
                $kunci_peminjaman = isset($_POST['kunci_peminjaman']) ? $_POST['kunci_peminjaman'] : "";
                ?>
                <form action="" method="post">
                    <label class="text-muted">Cari Peminjaman</label>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="kunci_peminjaman" class="form-control" placeholder="Masukkan Judul Buku" value="<?php echo $kunci_peminjaman; ?>">
                        <button class="btn btn-primary" type="submit">🔍 Cari</button>
                    </div>

                </form>
                <?php if ($kunci_peminjaman): ?>
                    <h6 class="text-primary">🔍 Hasil pencarian "<?php echo $kunci_peminjaman; ?>"</h6>
                <?php endif; ?>
                <table class="table table-bordered">
                    <tr class="table-success fw-bold text-center">
                        <td class="align-middle">NO</td>
                        <td class="align-middle">Judul Buku</td>
                        <td class="align-middle">Tanggal Pinjam</td>
                        <td class="align-middle">Aksi</td>
                    </tr>
                    <?php
                    include '../koneksi.php';
                    $no = 1;
                    $query = "SELECT * FROM transaksi,buku WHERE buku.id_buku=transaksi.id_buku AND transaksi.id_anggota='" . $_SESSION['id_anggota'] . "' AND status_transaksi='Peminjaman'";
                    if (isset($_POST['kunci_peminjaman']) && $_POST['kunci_peminjaman']) $query .= " AND judul_buku LIKE '%" . $_POST['kunci_peminjaman'] . "%'";
                    $data = mysqli_query($koneksi, $query);
                    foreach ($data as $peminjaman) { ?>
                        <tr class="text-center">
                            <td class="align-middle"><?php echo $no++; ?></td>
                            <td class="align-middle"><?php echo $peminjaman['judul_buku']; ?></td>
                            <td class="align-middle"><?php echo format_tanggal($peminjaman['tgl_pinjam']); ?></td>
                            <td class="align-middle">
                                <?php
                                $link = "'Pengembalian Buku " . $peminjaman['judul_buku'] . "'," . $peminjaman['id_transaksi'] . "," . $peminjaman['id_buku']; ?>
                                <a onclick="pengembalian(<?php echo $link; ?>)" class="btn btn-success me-1">✅ Pengembalian</a>
                                <a href="hapus_peminjaman.php?id=<?php echo $peminjaman['id_transaksi']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Batalkan peminjaman <?php echo $peminjaman['judul_buku']; ?>?')">🗑️ Batal</a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>

                <h4>📚 Daftar Buku</h4>
                <div class="row">
                    <?php
                    include '../koneksi.php';
                    $data_buku = mysqli_query($koneksi, "SELECT * FROM buku ORDER BY id_buku DESC");
                    foreach ($data_buku as $buku) { ?>
                        <div class="col-md-3">
                            <div class="card shadow-sm p-3 d-flex">
                                <h5><?php echo $buku['judul_buku']; ?></h5>
                                <p><strong>Pengarang :</strong> <?php echo $buku['pengarang']; ?></p>
                                <p><strong>Penerbit :</strong> <?php echo $buku['penerbit']; ?></p>
                                <p><strong>Diterbitkan Tahun :</strong> <?php echo $buku['tahun_terbit']; ?></p>
                                <p><strong>Stock :</strong> <?php echo $buku['stock']; ?></p>
                                <?php if ($buku['stock'] > 0) { ?>
                                    <span class="badge bg-success mb-1 text-white text-center">✅ Sisa Stock: <?php echo $buku['stock']; ?></span>
                                    <?php $link = "'❓ Apakah Anda Yakin Ingin Meminjam Buku " . $buku['judul_buku'] . "'," . $buku['id_buku']; ?>
                                    <a onclick="pinjam(<?php echo $link; ?>)" class="btn btn-primary text-white">🛒 Pinjam</a>
                                <?php } else { ?>
                                    <span class="badge bg-danger mb-1 text-white text-center">❌ Stock Habis (0)</span>
                                    <a class="btn btn-primary text-white disabled">🛒 Pinjam</a>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>

    </div>
</section>
<script>
    function pinjam(pesan, id_buku) {
        if (confirm(pesan)) {
            window.location.href = '?halaman=peminjaman&id=' + id_buku;
        }
    }

    function pengembalian(pesan, id_transaksi, id_buku) {
        if (confirm(pesan)) {
            window.location.href = 'pengembalian.php?id=' + id_transaksi + '&buku=' + id_buku;
        }
    }
</script>