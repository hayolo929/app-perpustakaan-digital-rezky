<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo isset($title) ? $title : 'User - Perpustakaan Digital'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <?php if (isset($custom_styles)) echo $custom_styles; ?>
</head>

<body>
    <!-- Legacy header deprecated - use simple_header.php with sidebar instead -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link <?php echo (!isset($_GET['halaman']) || $_GET['halaman'] == '') ? 'active btn btn-sm btn-outline-warning mx-1' : 'btn btn-sm btn-outline-warning mx-1'; ?>" href="dashboard_user.php" style="transition: all 0.3s ease; border-radius: 20px;">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (isset($_GET['halaman']) && $_GET['halaman'] == 'history') ? 'active btn btn-sm btn-outline-info mx-1' : 'btn btn-sm btn-outline-info mx-1'; ?>" href="?halaman=history" style="transition: all 0.3s ease; border-radius: 20px;">History</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn btn-sm btn-outline-danger mx-1" href="logout.php" style="transition: all 0.3s ease; border-radius: 20px;">Logout</a>
            </li>
        </ul>
        <style>
            .navbar-nav .nav-link:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(255, 255, 255, 0.4);
                background-color: rgba(255, 255, 255, 0.2) !important;
            }

            .navbar-nav .nav-link.active {
                background-color: rgba(255, 255, 255, 0.3) !important;
                font-weight: bold;
            }
        </style>
    </div>
    </div>
    </nav>