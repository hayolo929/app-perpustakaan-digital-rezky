<?php
$kunci = isset($_POST['kunci']) ? $_POST['kunci'] : "";
?>
<form action="?halaman=cari" method="POST">
    <label class="text-muted"> Yuk Cari Buku</label>
    <div class="input-group mb-3">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
        <input type="text" name="kunci" class="form-control" required placeholder="Masukkan Judul Buku">
        <button class="btn btn-primary" type="submit">🔍 Cari</button>
    </div>

</form>

<h4>🔍 Pencarian Buku "<?php echo $kunci; ?>"</h4>
<div class="row">
    <?php
    include '../koneksi.php';
    $data_buku = mysqli_query($koneksi, "SELECT * FROM buku WHERE judul_buku LIKE '%$kunci%'");
    foreach ($data_buku as $buku) {
    ?>
        <div class="col-md-3">
            <div class="card shadow-sm p-3 d-flex">
                <h5><?php echo $buku['judul_buku']; ?></h5>
                <p><strong>Pengarang :</strong> <?php echo $buku['pengarang']; ?></p>
                <p><strong>Penerbit :</strong> <?php echo $buku['penerbit']; ?></p>
                <p><strong>Diterbitkan Tahun :</strong> <?php echo $buku['tahun_terbit']; ?></p>
                <p><strong>Stock :</strong> <?php echo $buku['stock']; ?></p>
                <?php
                if ($buku['stock'] > 0) { ?>
                    <span class="badge bg-success mb-1 text-white text-center">✅ Sisa Stock: <?php echo $buku['stock']; ?></span>
                    <?php
                    $link = "'❓ Apakah Anda Yakin Ingin Meminjam Buku " . $buku['judul_buku'] . "'," . $buku['id_buku']; ?>
                    <a onclick="pinjam(<?php echo $link; ?>)" class="btn btn-primary text-white">🛒 Pinjam</a>
                <?php } else { ?>
                    <span class="badge bg-danger mb-1 text-white text-center">❌ Stock Habis (0)</span>
                    <a class="btn btn-primary text-white disabled">🛒 Pinjam</a>
                <?php } ?>
            </div>
        </div>
    <?php } ?>
</div>