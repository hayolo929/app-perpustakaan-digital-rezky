<?php
session_start();
if (!isset($_SESSION['id_anggota'])) {
    header("location:../login_anggota.php");
    exit;
}

include '../koneksi.php';

if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];
    $query = "DELETE FROM transaksi WHERE id_transaksi='$id_transaksi' AND id_anggota='" . $_SESSION['id_anggota'] . "' AND status_transaksi='Pengembalian'";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('✅ History peminjaman berhasil dihapus'); window.location.assign('history.php');</script>";
    } else {
        echo "<script>alert('❌ Gagal hapus history'); window.location.assign('history.php');</script>";
    }
} else {
    header("location:history.php");
}
