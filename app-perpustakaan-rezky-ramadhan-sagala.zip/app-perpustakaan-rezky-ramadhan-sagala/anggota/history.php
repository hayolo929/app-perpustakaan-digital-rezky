<h4> ✅ History Peminjaman :</h4>
<?php
$kunci = isset($_POST['kunci']) ? $_POST['kunci'] : "";
?>
<form action="" method="post">
    <label class="text-muted">Cari History</label>
    <div class="input-group mb-3">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
        <input type="text" name="kunci" class="form-control" placeholder="Masukkan Judul Buku" value="<?php echo $kunci; ?>">
        <button class="btn btn-primary" type="submit">🔍 Cari</button>
    </div>

</form>
<?php if ($kunci): ?>
    <h6 class="text-primary">🔍 Hasil pencarian "<?php echo $kunci; ?>"</h6>
<?php endif; ?>
<table class="table table-bordered">
    <tr class="table-success fw-bold text-center">
        <td class="align-middle">NO</td>
        <td class="align-middle">Judul Buku</td>
        <td class="align-middle">Tanggal Pinjam</td>
        <td class="align-middle">Tanggal Kembali</td>
        <td class="align-middle">Aksi</td>
    </tr>
    <?php
    include '../koneksi.php';
    $no = 1;
    $query = "SELECT * FROM transaksi,buku WHERE buku.id_buku=transaksi.id_buku AND transaksi.id_anggota='" . $_SESSION['id_anggota'] . "' AND status_transaksi='Pengembalian'";
    if ($kunci) $query .= " AND judul_buku LIKE '%$kunci%'";
    $data = mysqli_query($koneksi, $query);
    foreach ($data as $peminjaman) { ?>
        <tr class="text-center">
            <td class="align-middle"><?php echo $no++; ?></td>
            <td class="align-middle"><?php echo $peminjaman['judul_buku']; ?></td>
            <td class="align-middle"><?php echo format_tanggal($peminjaman['tgl_pinjam']); ?></td>
            <td class="align-middle"><?php echo format_tanggal($peminjaman['tgl_kembali']); ?></td>
            <td class="align-middle">
                <a href="hapus_history.php?id=<?php echo $peminjaman['id_transaksi']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus history <?php echo $peminjaman['judul_buku']; ?>?')">🗑️ Hapus</a>
            </td>
        </tr>
    <?php } ?>
</table>