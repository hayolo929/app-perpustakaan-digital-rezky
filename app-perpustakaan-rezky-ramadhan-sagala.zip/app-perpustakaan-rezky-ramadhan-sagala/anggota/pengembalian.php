<?php
include '../koneksi.php';
date_default_timezone_set("Asia/Jakarta");
$id_transaksi = $_GET['id'];
$tgl = date('Y-m-d H:i:s');
$buku = $_GET['buku'];
$query = "UPDATE transaksi SET tgl_kembali='$tgl', status_transaksi='Pengembalian' WHERE id_transaksi='$id_transaksi'";
$data = mysqli_query($koneksi, $query);
if ($data) {
    mysqli_query($koneksi, "UPDATE buku SET stock = stock + 1 WHERE id_buku='$buku'");
    echo "<script>alert('✅ Buku Berhasil Dikembalikan'); window.location.assign('dashboard_user.php');</script>";
}
