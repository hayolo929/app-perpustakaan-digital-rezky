<?php
session_start();
if (!isset($_SESSION['id_anggota'])) {
    header("location:../login_anggota.php");
    exit;
}

include '../koneksi.php';

if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];
    // Restore stock
    $transaksi = mysqli_fetch_array(mysqli_query($koneksi, "SELECT id_buku FROM transaksi WHERE id_transaksi='$id_transaksi'"));
    if ($transaksi) {
        mysqli_query($koneksi, "UPDATE buku SET stock = stock + 1 WHERE id_buku='{$transaksi['id_buku']}'");
    }
    $query = "DELETE FROM transaksi WHERE id_transaksi='$id_transaksi' AND id_anggota='" . $_SESSION['id_anggota'] . "'";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('✅ Peminjaman berhasil dibatalkan'); window.location.assign('dashboard.php');</script>";
    } else {
        echo "<script>alert('❌ Gagal batalkan peminjaman'); window.location.assign('dashboard.php');</script>";
    }
} else {
    header("location:dashboard.php");
}
