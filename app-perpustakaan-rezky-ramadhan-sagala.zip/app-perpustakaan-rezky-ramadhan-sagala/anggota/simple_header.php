<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo isset($title) ? $title : 'User - Perpustakaan Digital'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <?php if (isset($custom_styles)) echo $custom_styles; ?>
    <style>
        :root {
            --sidebar-width: 260px;
        }

        body {
            overflow-x: hidden;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: #08CB00;
            color: white;
            transition: transform 0.3s ease;
            z-index: 1040;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-nav .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            border-radius: 0;
            transition: all 0.3s;
        }

        .sidebar-nav .nav-link:hover,
        .sidebar-nav .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            transform: translateX(5px);
        }

        .content-wrapper {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left 0.3s ease;
        }

        .sidebar-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1039;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .sidebar-backdrop.show {
            opacity: 1;
            visibility: visible;
        }
    </style>
</head>

<body>



    <!-- Sidebar -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-header text-center">
            <img src="../logo-smk2.png" alt="SMK 2" height="50" class="mb-2">
            <h5 class="mb-0">Halaman User</h5>
            <small></small>
        </div>
        <ul class="nav flex-column sidebar-nav mt-3">
            <li class="nav-item">
                <a href="dashboard_user.php" class="nav-link <?php echo (!isset($_GET['halaman']) || $_GET['halaman'] == '') ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="?halaman=history" class="nav-link <?php echo (isset($_GET['halaman']) && $_GET['halaman'] == 'history') ? 'active' : ''; ?>">
                    <i class="fas fa-history me-2"></i> History
                </a>
            </li>
            <li class="nav-item mt-auto">
                <a href="logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>

    <!-- Main Content Wrapper -->
    <div class="content-wrapper">
        <header class="app-header text-center p-4 text-white" style="background-color: #08CB00;">
            <h4 class="mb-0">Aplikasi Perpustakaan Sekolah Digital</h4>
        </header>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>