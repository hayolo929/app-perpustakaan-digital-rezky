<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register User - Aplikasi Perpustakaan Sekolah Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="vh-100 row justify-content-center align-items-center">
        <form action="#" method="post" class="col-md-4 border p-3 bg-white rounded-4">
            <img src="logo-smk2.png" width="70px " class="mx-auto d-block">
            <h4 class="text-center">Pendaftaran Anggota</h4>
            <h5 class="text-center mb-3"> Aplikasi Perpustakaan Digital Sekolah</h5>
            <input type="text" name="nis" class="form-control mb-3" placeholder="Masukkan Nis">
            <input type="text" name="nama_anggota" class="form-control mb-3" placeholder="Masukkan Nama Anggota">
            <input type="text" name="username" class="form-control mb-3" placeholder="Masukkan username">
            <input type="text" name="password" class="form-control mb-3" placeholder="Masukkan Password">
            <input type="text" name="Kelas" class="form-control mb-3" placeholder="Masukkan Kelas">
            <button type="submit" name="tombol" class="btn btn-success w-100 mb-2">Daftar</button>
            <a href="login.php" class="text-decoration-none">Login..?</a>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
if (isset($_POST['tombol'])) {
    include 'koneksi.php';
    $nis = $_POST['nis'];
    $nama_anggota = $_POST['nama_anggota'];
    $username = $_POST['username'];
    $pass = $_POST['password'];
    $kelas = $_POST['kelas'];
    $query = "INSERT INTO anggota(nis,nama_anggota,username,password,kelas) VALUES ('$nis','$nama_anggota','$username','$pass','$kelas')";
    $data = mysqli_query($koneksi, $query);
    if ($data) {
        session_start();
        $_SESSION['id_anggota'] = mysqli_insert_id($koneksi);
        $_SESSION['username'] = $username;
        $_SESSION['nama_admin'] = $nama_anggota;
        header("Location:login.php");
    }
}
?>